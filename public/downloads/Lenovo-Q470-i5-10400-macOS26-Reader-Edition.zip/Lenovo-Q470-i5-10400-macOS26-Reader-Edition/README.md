# Lenovo Q470 / i5-10400 macOS Tahoe EFI

这是对应文章《从零安装 macOS Tahoe：Lenovo Q470 / i5-10400 黑苹果完整指南》的下载 EFI。

## 适用硬件

- 主板：Lenovo 316D / Q470，BIOS 基线 M2WKT46A。
- CPU：Intel Core i5-10400。
- 核显：Intel UHD 630，PCI ID `8086:9bc8`。
- 有线网卡：Intel I219-LM，PCI ID `8086:0d4c`。
- 无线网卡：Broadcom BCM4360，PCI ID `14e4:43a0`，子系统 `106b:0117`。
- 显示：HDMI 直连。

其他主板、CPU、USB 控制器或网卡不能直接套用。

## 包内配置

- `EFI/OC/config.plist`：安装和故障恢复使用，不加载 SimpleBCM。
- `EFI/OC/config.simplebcm.plist`：系统已经能独立启动后，用于启用 BCM4360、AirportBrcmFixup 和国家码参数。
- `EFI/OC/config.before-simplebcm.plist`：与默认安装配置相同，便于从 Wi-Fi 配置回退。

先把 `config.plist` 所在的 `EFI` 文件夹放到安装 U 盘的 EFI 分区根目录。安装完成、确认 SSD 能独立启动后，再把 `config.simplebcm.plist` 复制并替换为 `config.plist`。

`config.simplebcm.plist` 已追加以下启动参数，并保持现有参数不变：

```text
-brcmfxbeta brcmfx-country=#a
```

在 Lenovo 316D / BCM4360 实机上，这一步把无线链路从 40 MHz / 324 Mbps 提升到 80 MHz / 585 Mbps；同一测速端点下行从约 3.57 Mbps 恢复到 275.25 Mbps。

## 安全说明

公开包中的序列号、MLB、UUID 和 ROM 是明确标记的演示值，不能登录 Apple ID，也不应直接使用 iCloud、iMessage 等服务。准备使用 Apple 服务前，请用 OpenCore 的 `macserial` 或 OpenCore Configurator 为本机生成并保存独立身份，查询序列号状态后再登录。

## 最低 BIOS 设置

- UEFI 启动。
- Secure Boot、Fast Boot、VT-d 关闭。
- 主显示 IGD。
- DVMT Pre-Allocated 64 MB。
- SATA AHCI（系统盘为 NVMe 时仍建议确认）。
- CSM 关闭。

## 作为无显示器主机运行

若这台机器需要长期无人值守运行，在 macOS 中执行：

```bash
sudo pmset -a sleep 0 displaysleep 0 disksleep 0   powernap 0 standby 0 autopoweroff 0 hibernatemode 0   womp 1 proximitywake 0
```

同时确认 FileVault 为关闭状态：

```bash
fdesetup status
```

FileVault 开启时，断电或重启后必须连接显示器输入解锁密码；关闭 FileVault 后，远程登录服务可在无显示器环境中工作。是否关闭 FileVault 需要结合设备所在环境判断。

## 风险

EFI 只对文档列出的系统版本和硬件组合做过实机验证。升级 macOS、更换硬件或修改配置前，先完整备份当前 EFI。安装系统会抹掉目标磁盘，运行前确认数据已备份。
