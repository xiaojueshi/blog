# 上游来源与版本

| 组件 | 版本 | 来源 |
| --- | --- | --- |
| OpenCorePkg | 1.0.8 RELEASE | https://github.com/acidanthera/OpenCorePkg/releases/tag/1.0.8 |
| Lilu | 1.7.2 RELEASE | https://github.com/acidanthera/Lilu/releases/tag/1.7.2 |
| VirtualSMC | 1.3.8 RELEASE | https://github.com/acidanthera/VirtualSMC/releases/tag/1.3.8 |
| WhateverGreen | 1.7.1 RELEASE | https://github.com/acidanthera/WhateverGreen/releases/tag/1.7.1 |
| IntelMausi | 1.0.8 RELEASE | https://github.com/acidanthera/IntelMausi/releases/tag/1.0.8 |
| NVMeFix | 1.1.3 RELEASE | https://github.com/acidanthera/NVMeFix/releases/tag/1.1.3 |
| AppleALC | 1.9.8 RELEASE | https://github.com/acidanthera/AppleALC/releases/tag/1.9.8 |
| SimpleBCM | 1.0.0 Tahoe RELEASE | https://github.com/laobamac/SimpleBCM/releases/tag/v1.0.0 |
| AirportBrcmFixup | 2.2.1 RELEASE | https://github.com/acidanthera/AirportBrcmFixup/releases/tag/2.2.1 |

SimpleBCM Tahoe v1.0.0 RELEASE 压缩包 SHA-256：

```text
63ddca5ae7ae598a363fbeab82c3248d62d17ff122492aa74d0402c2fe1aa054
```

AirportBrcmFixup 2.2.1 RELEASE 压缩包 SHA-256：

```text
2432c8a62445ad2cdadcc59b73928f01f8bf42bcd3f4386e49bc63a1c91db06f
```

第三方组件版权与许可归各自上游项目所有。SimpleBCM 发行包中的许可文件和 AirportBrcmFixup 的上游许可证已保存在 `Licenses/`。
